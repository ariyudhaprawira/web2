<?php 

$host = "localhost";
$dbname = "ari_buku";
$username = "root";
$password = " ";
$db = "";

?>