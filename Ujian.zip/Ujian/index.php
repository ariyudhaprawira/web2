<?php 
require_once 'view/UtamaUI.php';

$uui = new UtamaUI();

$uui->tampilkanBuku();


 ?>